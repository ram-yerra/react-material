import React, {useState} from 'react';
import ReactDOM from 'react-dom';

function CustomerApp() {
  const [items, setItems] = useState(
    [{id:78878, name:"Vivek", email:'vivek@abc.com', phone:'784847746', address:'India'},
      {id:6767, name:"Shiva", email:'shiva@abc.com', phone:'898', address:'India'}]
  );

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [id, setId] = useState(0);
  const [buttonLabel, setLabel] = useState("Add Customer");


  var editRecord = (id) =>{
    console.log("editRecord: "+id);
    var newCustomers = items.filter((item)=>(item.id == id));
    let selectedRecord = newCustomers[0];
    //console.log(JSON.stringify(selectedRecord));
    setName(selectedRecord.name);
    setPhone(selectedRecord.phone);
    setEmail(selectedRecord.email);
    setAddress(selectedRecord.address);
    setId(selectedRecord.id);
    setLabel('Update Customer');
  }

  var deleteRecord = (id) =>{
    console.log("deleteRecord: "+id);
    var newCustomers = items.filter((item)=>(item.id!= id));
    setItems(newCustomers);
    // implement and remove item from state
  }
  

  var handleChange = (e) => {
    //this points to from
    console.log("update change");
    if([e.target.name] == 'name'){
      setName(e.target.value)
    }else if([e.target.name] == 'email'){
      setEmail(e.target.value)
    }else if([e.target.name] == 'phone'){
      setPhone(e.target.value)
    }else if([e.target.name] == 'address'){
      setAddress(e.target.value)
    }
  }

  var handleSubmit= (e) => {
    e.preventDefault();
    if (!name.length) {
      return;
    }

    let newItem = {
      name,email,address,phone
    };
    let newItems = [];
    
    if(id == 0){ //do add
        newItem.id = Date.now();
        newItems = items.concat(newItem);
    }else{ //do update
        newItem.id = id;
        for(var i = 0; i < items.length; i++){
            //records taken from the form
            newItems.push(items[i]);
            if(items[i].id == id){
                newItems[i].id = id;
                newItems[i].name = name;
                newItems[i].email = email;
                newItems[i].phone = phone;
            }
        }

    }

    setName('');
    setPhone('');
    setEmail('');
    setAddress('');
    setId(0);
    setItems(newItems);
    setLabel('Add Customer');
  }

    return (
      <div>
        <h3>Customer App</h3>
        <CustomerList items={items} deleteRecord={deleteRecord} updateRecord={editRecord}/>
        <form onSubmit={handleSubmit}>
          <input
            placeholder="Name"
            name="name"
            onChange={handleChange}
            value={name}
          /><br/><br/>
           <input
            placeholder="Email"
            name="email"
            onChange={handleChange}
            value={email}
          /><br/><br/>
           <input
            placeholder="Phone"
            name="phone"
            onChange={handleChange}
            value={phone}
          /><br/><br/>
           <input
            placeholder="Address"
            name="address"
            onChange={handleChange}
            value={address}
          /><br/><br/>
          <button>{buttonLabel}</button>
          <button>Cancel</button>
        </form>
      </div>
    );
}

function CustomerList({items,updateRecord,deleteRecord}){
    return (
        <div>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                {items.map(item => (
                    <tr key={item.id}>
                        <td >{item.id}</td>
                        <td id={item.id} >{item.name}</td>
                        <td>{item.email}</td>
                        <td>{item.phone}</td>
                        <td>{item.address}</td>
                        <td>
                            <button onClick={()=>{
                            updateRecord(item.id);
                        }}>edit</button>
                        </td>
                        <td><button onClick={()=>{
                           deleteRecord(item.id);
                        }}>delete</button></td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>

    );
}

export default CustomerApp;
