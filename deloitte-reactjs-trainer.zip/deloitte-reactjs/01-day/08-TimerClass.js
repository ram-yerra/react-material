import React, {Component} from 'react';
// login + html tied with each other
class Timer extends Component {
    constructor(props){ //
        super(props);
        this.state = {count : 0};
        console.log(">> constructor..");
        // state is used with GUI state 
    }
    UNSAFE_componentWillMount(){
        console.log(">> UNSAFE_componentWillMount");
    }
    componentDidMount(){ //
        console.log(">> componentDidMount");
        this.startTimer();
    }
    componentWillUnmount(){
        console.log(">> componentWillUnmount");
    }
    UNSAFE_componentDidUnMount(){
        console.log(">> componentWillUnmount");
    }
    componentWillReceiveProps(){

    }

    startTimer =() => { //function 
        var interval = setInterval(()=>{
           // this.state.count = this.state.count+1;
           // this.forceUpdate();
           // this.setState({count:this.state.count+1}); //
            this.setState((oldState)=>({count:oldState.count+1}));
        },1000)
    }
    // mount adding to parent on DOM


    render(){
        console.log("render");
        return (
        <div>
            <h2>Timer Example</h2>
            <h4>Count: {this.state.count}</h4>

        </div>
        );
    }
  }

  // var , let , this, function ()
  export default Timer;
  
