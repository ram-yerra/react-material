// map-type similar to Java
// key value pair
var map = new Map();

map.set('name',"Vivek");

map.get("name");

map = new Map();

map.set('name',"Vivek");
map.set('name',"Vivek");

console.log("map.get('name')::"+map.get('name'));

// only unique values to be added
var set = new Set();
set.add(4);
set.add(3);
set.add(4);



