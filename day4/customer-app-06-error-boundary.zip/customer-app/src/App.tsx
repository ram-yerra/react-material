import Person from './components/Person'; //class
import Student from './components/Student'; // functional component
import TodoApp from './components/TodoApp'; // functional component
import Home from './components/Home'; // functional component
import Customer from './components/CustomerApp'; // functional component
import About from './components/About'; // functional component
import Login from './components/Login'; // functional component
import AddCustomer from './components/AddCustomer'; // functional component
import Protected from './components/Protected'; // functional component
import CheckLogin from './components/CheckLogin'; // functional component
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import UserCtx from './components/UserContext';
import { useCustomEventListener } from 'react-custom-events';

import {useEffect, useState} from 'react';
import './App.css';

function App() {
   var loginStatus = () =>{
      if(localStorage.getItem('isLoggedIn') == 'true'){
        return true;
      }else{
        return false;
      }
    }

    useCustomEventListener('my-event', data => {
      console.log("my-event received in App.tsx "+JSON.stringify(data));
    });

    useEffect(()=>{

    },[])
    const [isLoggedIn, setIsLoggedIn] = useState(loginStatus());
    console.log("isLoggedIn::"+isLoggedIn);
  return (
   <Router>
   <UserCtx.Provider
     value={{
       isLoggedIn,
       doLogin: (code:string) =>{
         if(code == "admin"){
            setIsLoggedIn(true);
            localStorage.setItem('isLoggedIn',"true");
          }else{
            localStorage.removeItem('isLoggedIn');
            setIsLoggedIn(false)
          }
       }
     }}
   >
    <div style={{width:'96%',margin:'2%'}}>
       <Switch>
          <Route exact path='/customer/add' component={AddCustomer} />
          <Route exact path='/customer/edit/:id' component={AddCustomer} />
          <Route exact path='/' isLoggedIn={isLoggedIn} component={CheckLogin} />
          <Route exact path='/login' component={Login} />
          <Protected isLoggedIn={isLoggedIn} path="/home">
                <Home />
          </Protected>
          <Route exact path='/about' component={About} />
          <Route exact path='/customer' component={Customer} />
       </Switch>
    </div>
    </UserCtx.Provider>
 </Router>
  );
}
export default App;