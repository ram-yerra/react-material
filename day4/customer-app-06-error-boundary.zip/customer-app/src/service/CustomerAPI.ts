import {Customer} from '../types/AppTypes'

const apiEndPoint = "http://localhost:4000/customer";

export var getCustomers = () => {
    // fetch is promise
    return fetch(apiEndPoint, {
        method: 'get',
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        }
    })
        .then(response => response.json())
        .then(response => {
            console.log("data received from server...");
            return response;
        }).catch(function (error) {
            console.log(error);
        });
}

export var addCustomer = (customer:Customer) => {
    return  fetch(apiEndPoint, {
        method: 'post',
        body:JSON.stringify(customer),
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        }
     }).then(response => response.json())
        .then(response => {
            return response;
        }).catch(function (error) {
            console.log(error);
        });
}

export var deleteCustomer = (customerId:number) => {
    return  fetch(apiEndPoint, {
        method: 'delete',
        body:JSON.stringify({id:customerId}),
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        }
    })
        .then(response => response.json())
        .then(response => {
            return response;
        }).catch(function (error) {
            console.log(error);
        });
}

export var updateCustomer = (customer:Customer) => {
    console.log(">> updateCustomer..");
    return  fetch(apiEndPoint, {
        method: 'put',
        body:JSON.stringify(customer),
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        }
     }).then(response => response.json())
        .then(response => {
            return response;
        }).catch(function (error) {
            console.log(error);
        });
 }

 export var getCustomerById = (customerId:number) => {
    return  fetch(apiEndPoint+"/"+customerId, {
        method: 'get',
        headers: {
            'Content-Type': 'application/json;charset=utf-8'
        }
     });
 }