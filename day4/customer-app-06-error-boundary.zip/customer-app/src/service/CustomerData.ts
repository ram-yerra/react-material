import {Customer} from '../types/AppTypes'
var customers:Customer[];

customers= [
    {id:1,name:'Vivek S', email:'vivek@pyther.com', phone:"565656565", address:'India'},
    {id:2,name:'Rama', email:'rama@pyther.com', phone:"565656565", address:'India'},
    {id:3,name:'Kavita', email:'kavita@pyther.com', phone:"565656565", address:'India'},
    {id:4,name:'Krishna', email:'vivek@pyther.com', phone:"565656565", address:'India'},
    {id:5,name:'Rahim Khan', email:'vivek@pyther.com', phone:"565656565", address:'India'} 
];

export var getCustomers = () => {
    return customers;
}

export var addCustomer = (customer:Customer) => {
    customers.push(customer);
}

export var deleteCustomer = (customerId:number) => {
    var tempList = [];
    for(var i = 0; i < customers.length;i++) {
      if(customers[i].id != customerId){
        tempList.push(customers[i]);
      }
    }
    customers = tempList;
}

export var updateCustomer = (customer:Customer) => {
    var tempItems = customers;
    for(var i = 0; i < tempItems.length; i++){
      if(tempItems[i].id == customer.id){
        tempItems[i].phone = customer.phone;
        tempItems[i].name = customer.name;
        tempItems[i].email = customer.email;
        tempItems[i].address = customer.address;
        break;
      }
    }
 }

 export var getCustomerById = (customerId:number) => {
    var customer:Customer = {name:'',email:'',phone:'',id:0, address:''};
    for(var i = 0; i < customers.length; i++){
      if(customers[i].id == customerId){
        return customers[i];
      }
    }
    return customer;
 }