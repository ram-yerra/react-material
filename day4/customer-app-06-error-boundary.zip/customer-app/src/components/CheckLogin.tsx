import React from "react";
import { Route, Redirect } from "react-router-dom";

const CheckLogin = ({ isLoggedIn, children, path }:any) => {
    console.log("isLoggedIn:"+isLoggedIn);

  return (<Route
    render={() =>
      isLoggedIn ? (
        <Redirect
        to={{
          pathname: "/home"
        }}
      />
      ) : (
        <Redirect
          to={{
            pathname: "/login"
          }}
        />
      )
    }
  />
)
};

export default CheckLogin;