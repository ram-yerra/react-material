import React from 'react';
import ReactDOM from 'react-dom';
import Menu from './Menu';
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";

import {getCustomers,addCustomer,deleteCustomer,updateCustomer,getCustomerById} from '../service/CustomerAPI';
import {Customer} from '../types/AppTypes'
interface PropsType {
  history:any
}

interface ListPropsType {
    items: Customer[],
    edit:Function,
    delete:Function
}
export default class TodoApp extends React.Component <PropsType, {}> {
  state = { items:[], 
    name: '',email:'' ,phone:'',id:0, address:'',buttonLabel:"Add Customer"};
  constructor(_props:PropsType) {
    super(_props);  
  }
  componentDidMount = async () => {
     // call to service 
     let items =  await getCustomers();
     console.log("data received  in component");
     this.setState({items:items});
  }
  render() {
    return (
      <div>
        <Menu/>
        <Button variant="primary" onClick={()=>{
          this.props.history.push('/customer/add');
        }}>Add</Button><br/><br/>
        <TodoList items={this.state.items} edit={(id:number) => this.doEdit(id)} delete={(id:number) => this.toDelete(id)} />
      </div>
    );
  }
  doEdit = (id:number) =>{
    console.log('doEdit:'+id);
    this.props.history.push('/customer/edit/'+id);
  }
  handleChange = (e:any) => {
    this.setState({[e.target.name]: e.target.value });
  }
  updateState = async() =>{
    var customers = await getCustomers();
      this.setState({
        items:customers
    })
  }
  toDelete = async (id:number) =>{
    await deleteCustomer(id);
    this.updateState();
  }
  addCustomer = (e:any) => { //it is add & Update
      console.log("addCustomer");
    if (!this.state.name.length) {
      return;
    }
    if(this.state.id == 0){ //to add 
        const newItem = {
            name: this.state.name,
            email: this.state.email,
            address: this.state.address,
            phone: this.state.phone,
            id: Date.now()
          };
          addCustomer(newItem);
          this.setState((prevState:{items:any}) => ({
            items: getCustomers(),
            name: '',
            email:'',
            id:0,
            address:'',
            phone:''
          }));
          
    } else{ //to update 
        const newItem = {
            name: this.state.name,
            email: this.state.email,
            address: this.state.address,
            phone: this.state.phone,
            id: this.state.id
          };
          updateCustomer(newItem);
          this.setState({ 
            items:getCustomers(),
            name: '',
            email:'',
            id:0,
            address:'',
            phone:'',
            buttonLabel:"Add Customer"});
    }
  }
}

class TodoList extends React.Component <ListPropsType, {}> {
  render() {
    return (
      <Table striped bordered hover size="sm">
          <thead style={{width:'100%', border:'1px solid black'}} >
          <tr style={{width:'100%', border:'1px solid black'}}>
              <th>Sr No</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Address</th>
              <th>Edit</th>
              <th>Delete</th>
          </tr>
          </thead>
          <tbody>
        {this.props.items.map((item:any) => (
            <tr key={item.id}>
                <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.email}</td>
                <td>{item.phone}</td>
                <td>{item.address}</td>
                <td><Button variant="secondary" onClick={()=>this.props.edit(item.id)}>Edit</Button></td>
                <td><Button variant="danger"  onClick={()=>this.props.delete(item.id)}>Delete</Button></td>
            </tr>
        ))}
        </tbody>
      </Table>
    );
  }
}

