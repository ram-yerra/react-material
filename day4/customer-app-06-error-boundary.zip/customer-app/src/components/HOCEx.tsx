const withUser = (WrappedComponent:any) => {
    const user = "Vivek Singhwal";
    return (props:any) => <WrappedComponent user={user} {...props} />;
  };
  
  const UserPage = (props:any) => {
    return (<div>
      <h3>HOC Example...</h3>
      <p>My name is {props.user}!</p>
    </div>)
  };
  
  //see line no 13
  export default withUser(UserPage); //

  //DP
  // CC+SP1  CC+SP1