import React, {useState,useContext}from 'react';
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import UserContext from "./UserContext";

   function Login(props: { history: any }){
      const [username, setUsername] = useState("");
      const [password, setPassword] = useState("");
      const userContext = useContext(UserContext);

      var doLogin = async () => {
         if(username === ""){
            alert('Please provide username and password');
         } else {
           var response = await fetch("http://localhost:4000/login", {
               method: 'post',
               body:JSON.stringify({email:username,password:password}),
               headers: {
                   'Content-Type': 'application/json;charset=utf-8'
               }
           })
               .then(response => response.json())
               .then(response => {
                   return response;
               }).catch(function (error) {
                   console.log(error);
               });
               
               if(response.result == "success"){
                  userContext.doLogin("admin");
                  props.history.push('/customer');
               }else{
                  alert('username or password is incorrect');
               }
         
         }
      }
      var onHandleChange = (e:any)=>{
         if(e.target.name === 'username'){
            setUsername(e.target.value)
         }else if (e.target.name === 'password'){
            setPassword(e.target.value)
         }
      }
      return (
         <div style={{width:'80%',margin:'10%'}}>
            <h2>Customer App</h2>
            <Form>
               <Form.Group controlId="formBasicEmail">
                  <Form.Label>Email address</Form.Label>
                  <Form.Control name="username" type="email" placeholder="Enter email" onChange={onHandleChange} value={username} />
                  <Form.Text className="text-muted">
                     We'll never share your email with anyone else.
                  </Form.Text>
               </Form.Group>

               <Form.Group controlId="formBasicPassword">
                  <Form.Label>Password</Form.Label>
                  <Form.Control name="password" type="password" placeholder="Password" onChange={onHandleChange}  value={password} />
               </Form.Group>
               <Form.Group controlId="formBasicCheckbox">
                  <Form.Check type="checkbox" label="Check me out" />
               </Form.Group>
               <Button  onClick={doLogin}  variant="primary" type="submit">
                  Login
               </Button> &nbsp;
               <Button  onClick={(e:any)=>{
                  e.preventDefault();
                  props.history.push('/home');
               }}  variant="secondary" >
                  Test Protected 
               </Button>
               </Form>
         </div>
      );
   }
    export default Login;