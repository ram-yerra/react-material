import React, { Component } from 'react';
//Coposition DP
//Child
function FancyBorder(props:any) {
  return (
    <div style={{color: props.color, backgroundColor: 'grey'}} >
      {props.children}
    </div>
  );
}

//Parent
export default function WelcomeDialog() {
  return (
    <FancyBorder color="blue">
      <h1 className="Dialog-title">
        Welcome to Composition
      </h1>
      <p className="Dialog-message">
        Thank you for visiting our spacecraft!
      </p>
    </FancyBorder>
  );
}
