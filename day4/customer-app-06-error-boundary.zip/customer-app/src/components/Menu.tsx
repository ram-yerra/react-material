import React,{useContext} from 'react';
import UserContext from "./UserContext";
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
   function Menu() {
      const userContext = useContext(UserContext);
      return (
         <div>
          <Link to={'/home'}>Home</Link>  &nbsp;|&nbsp;  
          <Link to={'/customer'}>Customer</Link> &nbsp;&nbsp;|&nbsp;&nbsp;  
          <Link to={'/about'}>About</Link> |  &nbsp;&nbsp;  
          <Link to={'/login'} onClick={
             ()=>{
               userContext.doLogin("");
             }
          }>Logout</Link>
        <hr />
         </div>
      );
   }
    export default Menu;