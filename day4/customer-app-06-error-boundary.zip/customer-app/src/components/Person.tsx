import React from 'react'

interface props{
    name:string,
    email:string
}
interface state { }

class Person extends React.Component<props,state> {
    state:any;
    constructor(props:props){
        super(props);
        this.state={name:props.name};
    }
    componentDidMount(){

    }

    doTest=()=>{
        console.log("Name is "+this.state.name);
        this.setState({name:"Rinku"});
    }

    render(){
        return(
            <div>
                <h2>Student Name:{this.state.name}</h2>
                <button onClick={this.doTest}>test</button>
            </div>
        )
    }
}
export default Person;
