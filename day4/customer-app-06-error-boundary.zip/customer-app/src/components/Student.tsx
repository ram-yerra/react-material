import {useState,useEffect} from 'react';
interface props {
    name:string,
    email:string
}

function Student({name,email}:props) {
    const [val, setVal] = useState(name);
    const [count, setCount] = useState(0);
    const [intervalId, setIntervalId] = useState(0);
    useEffect(()=>{
      console.log("call in the start")
      startTimer();
    },[]); //called on mount

    var startTimer =() => { //function 
      let interval:any = setInterval(()=>{
         setCount((count)=>(count+1));
      },1000);
      setIntervalId(interval);
   }
    var doTest = () =>{
        console.log("name is "+name);
        setVal("Random");
    }
  return (
    <div>
        <h4>Functional Count: {count}</h4>
        <h2>Person name {val} </h2>
        <input value="test" required></input>
        <button onClick={doTest} >test</button>
    </div>
  );
}
export default Student;
