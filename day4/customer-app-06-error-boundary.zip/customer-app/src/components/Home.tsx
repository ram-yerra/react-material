import React,{useState,useContext, useReducer} from 'react';
import Menu from './Menu';
export interface LoginData {
   username: string;
   password: string;
 }
   function Home() {
      //Type 
      const [val, setVal] = useState<LoginData|undefined>({username:"",password:""});
      const [count, setCount] = useState<Number|undefined>(8989);
      return (
         <div>
             <Menu/>
            <h2>Home</h2>
            <ContextApp/>
         </div>
      );
   }
   

const themes = {
    light: {
      foreground: "#000000",
      background: "#eeeeee",
      name:"Light theme"
    },
    dark: {
      foreground: "#ffffff",
      background: "#222222",
      name:"Dark theme"
    }
  };
  
  //const ThemeContext = React.createContext(themes.light);
  const ThemeContext:any = React.createContext(themes.light);// create with default Value
  
  function ContextApp() {
    return (
      <ThemeContext.Provider value={themes.light}>
        <Toolbar />
      </ThemeContext.Provider>
    );
  }
  
  function Toolbar() {
    return (
      <div>
        <ThemedButton />
      </div>
    );
  }
  
  function ThemedButton() {
    const theme:any = useContext(ThemeContext);
    return (
      <div>
        <h4>The theme is {theme.name}</h4>
        <button style={{ background: theme.background, color: theme.foreground }}>
          I am styled by theme context!
        </button>
      </div>

    );
  }

  export default Home;