import { AnyARecord } from 'dns';
import React,{useContext,useReducer, useState} from 'react';

const initialState = {count: 0};

function reducer(state:any, action:any) {
  switch (action.type) { //action
    case 'increment':
      return {count: state.count + 1};
    case 'decrement':
      return {count: state.count - 1};
    default:
      throw new Error();
  }
}

function Counter() {
  const [name, setName] = useState("initial");
  const [state, dispatch] = useReducer(reducer, initialState);
 
  return (
    <>
      Count: {state.count} <br/><br/>
      <button onClick={() => dispatch({type: 'decrement'})}>-</button> &nbsp;&nbsp;
      <button onClick={() => dispatch({type: 'increment'})}>+</button>
    </>
  );
}

export default Counter;