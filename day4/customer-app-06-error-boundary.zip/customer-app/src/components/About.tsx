import React from 'react';
import Menu from './Menu';
import {getCustomers} from '../service/CustomerData';
import ReducerEx from './ReducerExample';
import CompositionEx from './CompositionEx';
import HOCEx from './HOCEx';
import ErrorBoundaryEx from './ErrorBoundaryEx';

   function About() {
      return (
         <div>
             <Menu/>
            <h2>About</h2>
            <p>This is Customer App and it has {getCustomers().length} records.</p>
            <ErrorBoundaryEx/>
            <HOCEx/>
            <CompositionEx/>
            <ReducerEx/>

         </div>
      );
   }
    export default About;