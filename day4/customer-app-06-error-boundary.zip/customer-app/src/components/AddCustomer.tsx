import React,{useEffect,useState} from 'react';
import {addCustomer,getCustomerById, updateCustomer} from '../service/CustomerAPI';
import {Customer} from '../types/AppTypes';
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import { emitCustomEvent } from 'react-custom-events';

   function AddCustomer({history,match}:any){
      const [customerId, setCustomerId] = useState(0);
      const [bLabel, setBLabel] = useState("Add Customer");

      const [nameInput, setNameInput] = useState<any>(React.createRef());
      const [emailInput, setEmailInput] = useState<any>(React.createRef());
      const [phoneInput, setPhoneInput] = useState<any>(React.createRef());
      const [addressInput, setAddressInput] = useState<any>(React.createRef());
     
      // generator 
      // var nameInput:any = React.createRef();
      //var emailInput:any = React.createRef();
      //var phoneInput:any = React.createRef();
      //var addressInput:any = React.createRef();
     
      //Implemenet Edit Customer
      // Form should populate
      // addUpdateCustomer handle based on customer.id
      /*
         useEffect(
            ()=>{

            },[]
         );
         mount / unmount / props / events

         1. X / 
         old clean 
         2. useEffect
      */
      useEffect( () => {
         console.log(" >> useEffect");
        var x=  setInterval(()=>{ console.log("do interval ..") },1000);
        if(match.params.id){
            setCustomerId(match.params.id)
            getCustomerById(match.params.id)
            .then(response => response.json())
            .then((customer) => {
               // async in nature | coponent in  GUI | hooks
               console.log(JSON.stringify(customer));
               nameInput.current.value = customer.name;
               emailInput.current.value = customer.email;
               phoneInput.current.value = customer.phone;
               addressInput.current.value = customer.address;
               setBLabel('Update Customer');
            });
        } return(()=>{
          clearInterval(x);
        })
      },[])
      //controlledInput
      // React.createRef same as jQuery
      var addUpdateCustomer = async () => {
         emitCustomEvent('my-event', "TEST DATA");
         if(nameInput.current.value.length > 3){
            console.log("new Name:"+nameInput.current.value);
            let customer:Customer = {
                id:Date.now(),
                name:nameInput.current.value,
                email:emailInput.current.value,
                phone:phoneInput.current.value,
                address:addressInput.current.value
            }
            if(customerId != 0){
                customer.id= customerId;
                console.log(JSON.stringify(customer));
                await updateCustomer(customer);
            }else{
               await addCustomer(customer);
            }
            history.push('/customer');
         }else{
            alert("Please enter minimun 4 chars in name.")
         }  
      }
      return (
         <div style={{width:'96%',margin:'2%'}}>
            <h2>Add Customer</h2>
            <input ref={nameInput}  type="text" placeholder="Name" /> <br/><br/>
            <input ref={emailInput} type="text" placeholder="Email" /> <br/><br/>
            <input ref={phoneInput}  type="text" placeholder="Phone" /> <br/><br/>
            <input ref={addressInput}  type="text" placeholder="Address" /> <br/><br/>
            <Button variant="primary"  onClick={addUpdateCustomer}>{bLabel}</Button>

            <Button onClick={()=>{
               console.log("do cancel...");
               setCustomerId((val)=> (val+1));
            }}>Cancel</Button>
         </div>
      );
   }
    export default AddCustomer;
