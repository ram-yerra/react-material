import { createContext } from "react";
export default createContext({
    isLoggedIn:false,
    doLogin: (code:string) =>{}
  });