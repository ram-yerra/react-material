import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/Customer App/i);
  expect(linkElement).toBeInTheDocument();
});
// SSD 8 GD