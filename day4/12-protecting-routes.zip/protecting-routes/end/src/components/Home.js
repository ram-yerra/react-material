import React from "react";

const Home = () => {
  return (
    <div className="home">
      <h3>
        Welcome to the Book Store app! You can browse our collection on the
        Books page
      </h3>
    </div>
  );
};

export default Home;
