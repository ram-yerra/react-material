import React from 'react'

const Copyright: React.FC = () => (
  <footer className="info">
    <p>TodoMVC</p>
  </footer>
)

export default Copyright
